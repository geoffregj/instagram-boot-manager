# Status

**If you're an AI picking up work on this project: read this whole file
before touching any code.** If you're about to make a change, update the
relevant section below as part of *that same delivery* — not as an
afterthought, not "next time." An out-of-date STATUS.md is worse than no
STATUS.md, because it makes a stale state look current.

**If you're Geoffrey starting a new session (with either AI):** paste this
file in first, before describing what you want done. That's the whole
protocol — one file, pasted at the start of a session, instead of
re-uploading zips and hoping both threads end up seeing the same state.

---

## Last updated

- **When:** 2026-08-08 (later same day)
- **By:** Claude (Sonnet 5), this thread
- **What changed:** Fixed the Groq backend — `llama-3.3-70b-versatile` was
  deprecated by Groq on 2026-06-17, which is what was actually causing
  "Groq connection errors" (not a real connectivity issue). Default
  changed to `openai/gpt-oss-20b`, added the same HTTPError-body-surfacing
  treatment Gemini already had, added conversation history support (Groq's
  reply_fn was the only backend still ignoring `hist`), and gave it the
  same persisted-key treatment as Gemini (`.ig_manager_gemini.json`, now
  shared across both backends under different keys). Fixed a real bug this
  surfaced: `_save_gemini_config` did a full overwrite instead of a merge,
  which would have silently wiped Groq's saved key the next time Gemini
  was used — fixed to merge. Added menu option 12 (update saved
  API keys/config) instead of requiring manual file deletion to change
  one. Changed the Ollama backend's default model from `qwen2.5-coder:7b`
  to `llama3.1:8b` — confirmed firsthand that the coder variant produces
  noticeably worse casual-conversation replies, so it shouldn't be the
  default suggestion anymore (still usable if explicitly chosen, just not
  what a blank Enter gives you).

## Current known-good state

Confidence noted per feature — "confirmed" means there's real terminal
output from an actual run, not just that the code looks right on review.

| Feature | Status | Evidence |
|---|---|---|
| Login (all 4 methods) | confirmed | used repeatedly across sessions |
| Analyze followers/following (option 1) | confirmed (DOM path), untested (new API fast-path) | DOM scroll confirmed multiple runs; API fast-path just added, not yet run |
| Unfollow (option 2) | confirmed | real unfollows executed and logged |
| Seed-follow (option 3) | untested | fixed alongside unfollow's dialog-open bug, never actually run |
| DM auto-reply (option 4, Gemini) | confirmed | 8 real Gemini-generated replies sent successfully |
| DM auto-reply (option 4, Groq) | untested (post-fix) | model was deprecated and erroring before this fix; new model/error-handling/history support never actually run |
| DM auto-reply (option 4, Ollama) | untested | never reported as run |
| Comment auto-reply (option 5) | untested | hardened to match DM's robustness, never actually run |
| Update saved config (option 12) | untested | just added, never actually run |
| Story posting, growth log, profile audit, bulk like, hashtag research, notifications digest | untested | never reported as run in either thread |

## In progress / do not touch

*(nothing right now — if you start something that will take more than one
message to finish, list it here with which file/function, so the other
thread doesn't collide with it)*

## Open decisions waiting on Geoffrey

- **License:** defaulted to MIT in this delivery. Confirm or change
  `LICENSE`.
- **Gemini rate limits:** hitting 429s on `gemini-3.6-flash` free tier.
  Check https://aistudio.google.com/rate-limit for actual current quota —
  neither AI thread can see this from here.

## Standing risks (don't re-litigate these without new evidence)

- Automating Instagram violates its ToS regardless of method (DOM-clicking
  vs private API). This is a known, accepted risk, not an open question.
- The `X-IG-App-ID: 936619743392459` header gets Instagram's private
  **DM/inbox** endpoints rejected with "useragent mismatch" — confirmed on
  this account, on two independent code paths (`cortana_mint.py`'s login
  flow and an earlier `ig_manager.py` DM attempt). DM/comment reply
  therefore drives the real browser, not the API.
- The same header, on the **friendships** endpoints (unfollow, follower/
  following lists), has *not* shown the same rejection across repeated use
  — currently treated as lower-risk for those specific endpoints only.
  This is observed behavior, not a guarantee; if it starts failing, that's
  new evidence, revisit it then.
- Any API key or password that's appeared on-screen (screenshot or pasted
  terminal output) should be treated as burned. This has happened at least
  twice (an Instagram password, a Gemini key) — check `CHANGELOG.md` for
  specifics before assuming an old warning is stale.
